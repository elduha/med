from v1.appointments.models import Appointment
from django.contrib import admin

admin.site.register(Appointment)

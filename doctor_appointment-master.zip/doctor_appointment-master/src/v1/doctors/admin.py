from v1.doctors.models import Doctor, DoctorAdvice
from django.contrib import admin

admin.site.register(Doctor)
admin.site.register(DoctorAdvice)
